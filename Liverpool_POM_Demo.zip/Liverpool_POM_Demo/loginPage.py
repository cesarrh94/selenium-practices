from selenium.webdriver.common.by import By

class LoginPage():
     
    def __init__(self, driver):
        self.driver = driver
        
        # element locators
        self.email_input_id = 'username'
        self.password_input_id = 'password'
        self.login_button_name = 'action'
        self.verification_code_id = 'code'
        self.continue_button_name = 'action'
        self.create_account_link_xpath = '/html/body/code/main/section/div/div/div/div[1]/p/a'


    # actions
    def enter_email(self, email):
        self.driver.find_element(by=By.ID, value=self.email_input_id).send_keys(email)
        print(f"typing email: {email}")
    
    def enter_password(self, password):
        self.driver.find_element(by=By.ID, value=self.password_input_id).send_keys(password)
        print("typing PASSWORD")
    
    def click_login_button(self):
        self.driver.find_element(by=By.NAME, value=self.login_button_name).click()
        print("clicking Login button!")
    
    def enter_verification_code(self, code):
        self.driver.find_element(by=By.ID, value=self.verification_code_id).send_keys(code)
        print(f"verification code by SMS: {code}")
    
    def click_continue_button(self):
        self.driver.find_element(by=By.NAME, value=self.continue_button_name).click()
        print("clicking Continue button!")
    
    def click_create_account_link(self):
        self.driver.find_element(by=By.XPATH, value=self.create_account_link_xpath).click()
        print("clicking Create Account link!")