from selenium.webdriver.common.by import By

class SearchPage():

    def __init__(self, driver):
        self.driver = driver

        # element locators
        self.liverpool_logo = ""
        self.searchbar_input_id = "mainSearchbar"
        self.searchbar_button_xpath = '//*[@id="__next"]/header/div[4]/div[2]/div/div/div/div[3]/div/div/div/button'
        self.my_orders_link_xpath = '//*[@id="__next"]/header/div[3]/div[2]/div/div/div/div[4]/a'
        self.login_link_xpath = '//*[@id="__next"]/header/div[3]/div[2]/div/div/div/div[5]/span'
        self.view_cart_link_xpath = '//*[@id="__next"]/header/div[3]/div[1]/div/div/div/div[6]/button'

        self.results_title_xpath = '//*[@id="__next"]/div[1]/div[1]/div/div[4]/main/div[1]/div/div/div[2]/p/span'
        self.null_product_message_xpath = '/html/body/div[1]/div[1]/div/div[2]/div/div[1]/div/div[1]/p'
        self.product_card_id = 'img_0'
    
    # actions
    def get_search_results(self):
        search_result = self.driver.find_element(by=By.XPATH, value=self.results_title_xpath).text
        return search_result
    
    def get_null_product_message(self):
        message = self.driver.find_element(by=By.XPATH, value=self.null_product_message_xpath).text
        return message
    
    def click_product_card(self):
        self.driver.find_element(by=By.ID, value=self.product_card_id).click()
        print("clicking Product card!")