from selenium.webdriver.common.by import By

class ProductPage():
     
    def __init__(self, driver):
        self.driver = driver
        
        # element locators
        self.liverpool_logo = ""
        self.searchbar_input_id = "mainSearchbar"
        self.searchbar_button_xpath = '//*[@id="__next"]/header/div[4]/div[2]/div/div/div/div[3]/div/div/div/button'
        self.my_orders_link_xpath = '//*[@id="__next"]/header/div[3]/div[2]/div/div/div/div[4]/a'
        self.login_link_xpath = '//*[@id="__next"]/header/div[3]/div[2]/div/div/div/div[5]/span'
        self.view_cart_link_xpath = '//*[@id="__next"]/header/div[3]/div[1]/div/div/div/div[6]/button'

        self.product_quantity_input_id = 'a-ProductQty__inputDesktop'
        self.buyNow_button_id = 'opc_pdp_buyNowButton'


    # actions
    def enter_quantity(self, number):
        self.driver.find_element(by=By.ID, value=self.product_quantity_input_id).clear()
        self.driver.find_element(by=By.ID, value=self.product_quantity_input_id).send_keys(number)
        print(f"productQuantity: {number}")
        
    def click_buyNow_button(self):
        self.driver.find_element(by=By.ID, value=self.buyNow_button_id).click()
        print(f"clicking BuyNow button!")