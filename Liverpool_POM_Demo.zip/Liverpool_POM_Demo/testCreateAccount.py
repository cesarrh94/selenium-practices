import unittest

from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep

from homePage import HomePage as Hp
from loginPage import LoginPage as Lp
from createAccountPage import CreateAccountPage as Cap

class TestCreateAccount(unittest.TestCase):
    
    def setUp(self):
        CHROMEDRIVER_PATH = 'C:\\Optionals\\selenium-webdriver\\chromedriver.exe'
        self.driver = webdriver.Chrome(CHROMEDRIVER_PATH)
    
    def test_createAccountProcess(self):
        self.driver.get('https://www.liverpool.com.mx/tienda/home')
        self.driver.maximize_window()
        homepage = Hp(self.driver)
        homepage.click_login_link()
        sleep(3)
        loginpage = Lp(self.driver)
        loginpage.click_create_account_link()
        sleep(6)
        createaccountpage = Cap(self.driver)
        createaccountpage.enter_email('refifo1847@3mkz.com')
        createaccountpage.enter_password('Lunes2410')
        createaccountpage.click_create_account_button()
        sleep(6)
        
        
    def tearDown(self):
        self.driver.close()
        self.driver.quit()
        sleep(3)