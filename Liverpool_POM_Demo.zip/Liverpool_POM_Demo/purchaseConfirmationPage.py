from selenium.webdriver.common.by import By

class PurchaseConfirmationPage():
     
    def __init__(self, driver):
        self.driver = driver
        
        # element locators
        self.liverpool_logo = ""

        self.cash_and_transfer_button_id = 'opc_selectC'
        self.container_payment_method_id = 'opc_container'
        self.payment_method_option_button_id = 'billingCASH'
        self.continue_button_xpath = '//*[@id="opc_deliveryPayModalButtons"]/div/button'
        self.checkout_button_id = 'submitForOther'

    # actions
    def click_cash_and_transfer_button(self):
        self.driver.find_element(by=By.ID, value=self.cash_and_transfer_button_id).click()
        print("clicking Cash & Transfer button!")
    
    def click_payment_method_option_button(self):
        self.driver.find_element(by=By.ID, value=self.payment_method_option_button_id).click()
        print("clicking Continue button!")
    
    def click_continue_button(self):
        self.driver.find_element(by=By.XPATH, value=self.continue_button_xpath).click()
        print("clicking Payment Method Option button!")
        
    def click_checkout_button(self):
        self.driver.find_element(by=By.ID, value=self.checkout_button_id).click()
        print("clicking Checkout button!")