from selenium.webdriver.common.by import By

class CreateAccountPage():
     
    def __init__(self, driver):
        self.driver = driver
        
        # element locators
        self.email_input_id = 'username'
        self.password_input_id = 'password'
        self.create_account_button_name = 'action'
        
        self.names_input_id = 'input-user__name'
        self.last_name_1_id = 'input-user__apaterno'
        self.last_name_2_id = 'input-user__amaterno'
        
        self.select_day_from_list_id = 'daySelectorLabel'
        self.select_month_from_list_id = 'monthSelectorLabel'
        self.select_year_from_list_id = 'yearSelectorLabel'
        
        self.select_female_from_sex_gender_id = 'female'
        self.select_male_from_sex_gender_id = 'male'
        
        self.country_input_name = 'state' # Mexico default value
        self.mobile_phone_number_input_id = 'phone'
        
        self.verification_code_id = 'code'
        self.continue_button_name = 'action'


    # actions
    def enter_email(self, email):
        self.driver.find_element(by=By.ID, value=self.email_input_id).send_keys(email)
        print(f"typing email: {email}")
    
    def enter_password(self, password):
        self.driver.find_element(by=By.ID, value=self.password_input_id).send_keys(password)
        print("typing PASSWORD")
    
    def click_create_account_button(self):
        self.driver.find_element(by=By.NAME, value=self.create_account_button_name).click()
        print("clicking Login button!")
    
    def enter_verification_code(self, code):
        self.driver.find_element(by=By.ID, value=self.verification_code_id).send_keys(code)
        print(f"verification code by SMS: {code}")
    
    def click_continue_button(self):
        self.driver.find_element(by=By.NAME, value=self.continue_button_name).click()
        print("clicking Continue button!")