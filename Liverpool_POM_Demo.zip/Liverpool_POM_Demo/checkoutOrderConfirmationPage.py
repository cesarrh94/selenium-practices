from selenium.webdriver.common.by import By

class CheckoutOrderConfirmationPage():
     
    def __init__(self, driver):
        self.driver = driver
        
        # element locators
        self.liverpool_logo = ''
        self.gratitude_message_xpath = '//*[@id="order-confirmation-page"]/div[1]/div/div[2]'


    # actions
    def get_gratitude_message(self):
        message = self.driver.find_element(by=By.XPATH, value=self.gratitude_message_xpath)
        return message.text