import unittest

from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep

from homePage import HomePage as Hp
from loginPage import LoginPage as Lp
from searchPage import SearchPage as Sp
from productPage import ProductPage as Pp
from purchaseConfirmationPage import PurchaseConfirmationPage as Pcp
from checkoutOrderConfirmationPage import CheckoutOrderConfirmationPage as Cocp

class TestSearchBar(unittest.TestCase):
    
    def setUp(self):
        CHROMEDRIVER_PATH = 'C:\\Optionals\\selenium-webdriver\\chromedriver.exe'
        self.driver = webdriver.Chrome(CHROMEDRIVER_PATH)
    
    def test_buyingValidProduct(self):
        self.driver.get('https://www.liverpool.com.mx/tienda/home')
        self.driver.maximize_window()
        homepage = Hp(self.driver)
        homepage.click_login_link()
        sleep(3)
        loginpage = Lp(self.driver)
        loginpage.enter_email('94cesarrh@gmail.com')
        loginpage.enter_password('Benjito6')
        loginpage.click_login_button()
        sleep(6)
        verification_code = input("please type the verification code from the SMS: ")
        sleep(15)
        loginpage.enter_verification_code(verification_code)
        loginpage.click_continue_button()
        sleep(9)
        homepage.enter_product_name('Samsung UHD 65 pulgadas 4k')
        sleep(6)
        homepage.click_search_button()
        sleep(6)
        searchpage = Sp(self.driver)
        searchpage.click_product_card()
        sleep(6)
        productpage = Pp(self.driver)
        # productpage.enter_quantity(1)
        productpage.click_buyNow_button()
        sleep(6)
        purchaseconfimationpage = Pcp(self.driver)
        purchaseconfimationpage.click_cash_and_transfer_button()
        sleep(3)
        purchaseconfimationpage.click_payment_method_option_button()
        sleep(3)
        purchaseconfimationpage.click_continue_button()
        sleep(3)
        purchaseconfimationpage.click_checkout_button()
        sleep(9)
        checkoutorderconfirmationpage = Cocp(self.driver)
        message = checkoutorderconfirmationpage.get_gratitude_message()
        assert message == "¡Cesar Ivan Rodriguez , gracias por comprar!"
        sleep(6)
        
    def tearDown(self):
        self.driver.close()
        self.driver.quit()
        sleep(3)