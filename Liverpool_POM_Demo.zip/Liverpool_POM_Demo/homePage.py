from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class HomePage():
     
    def __init__(self, driver):
        self.driver = driver
        
        # element locators
        self.liverpool_logo = ""
        self.searchbar_input_id = "mainSearchbar"
        self.searchbar_button_xpath = '/html/body/div[1]/header/div[3]/div[2]/div/div/div/div[3]/div/div/div/button'
        self.my_orders_link_xpath = '//*[@id="__next"]/header/div[3]/div[2]/div/div/div/div[4]/a'
        self.login_link_xpath = '//*[@id="__next"]/header/div[3]/div[2]/div/div/div/div[5]/span'
        self.view_cart_link_xpath = '//*[@id="__next"]/header/div[3]/div[1]/div/div/div/div[6]/button'
        self.banner_section_id = "bannerNo-1"


    # actions
    def click_login_link(self):
        self.driver.find_element(by=By.XPATH, value=self.login_link_xpath).click()
        print("clicking Login link!")
    
    def enter_product_name(self, productName):
        self.driver.find_element(by=By.ID, value=self.searchbar_input_id).send_keys(productName)
        print(f"productName: {productName} type on SearchBar")
    
    def press_enter_on_searchbar(self):
        self.driver.find_element(by=By.ID, value=self.searchbar_input_id).send_keys(Keys.ENTER)

    def click_search_button(self):
        self.driver.find_element(by=By.XPATH, value=self.searchbar_button_xpath).click()
        print("clicking Search button!")