import unittest

from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep

from homePage import HomePage as Hp
from searchPage import SearchPage as Sp

class TestSearchBar(unittest.TestCase):
    
    def setUp(self):
        CHROMEDRIVER_PATH = 'C:\\Optionals\\selenium-webdriver\\chromedriver.exe'
        self.driver = webdriver.Chrome(CHROMEDRIVER_PATH)
    
    def test_searchBarWithValidProductName(self):
        self.driver.get('https://www.liverpool.com.mx/tienda/home')
        self.driver.maximize_window()
        sleep(6)
        homepage = Hp(self.driver)
        homepage.enter_product_name('iphone')
        homepage.press_enter_on_searchbar()
        # homepage.click_search_button()
        sleep(6)
        searchpage = Sp(self.driver)
        search_results = searchpage.get_search_results()
        search_results = int(search_results)
        assert search_results > 0
        sleep(3)
    
    def test_searchBarWithInvalidProductName(self):
        self.driver.get('https://www.liverpool.com.mx/tienda/home')
        self.driver.maximize_window()
        sleep(5)
        homepage = Hp(self.driver)
        homepage.enter_product_name('kbdfans')
        homepage.press_enter_on_searchbar()
        # homepage.click_search_button()
        sleep(6)
        searchpage = Sp(self.driver)
        null_message = searchpage.get_null_product_message()
        assert null_message == 'Lo sentimos, no encontramos nada para "kbdfans"'
        sleep(3)
    
    def test_searchBarWithSpecificProductName(self):
        self.driver.get('https://www.liverpool.com.mx/tienda/home')
        self.driver.maximize_window()
        sleep(6)
        homepage = Hp(self.driver)
        homepage.enter_product_name('iphone 13 pro max')
        homepage.press_enter_on_searchbar()
        # homepage.click_search_button()
        sleep(6)
        searchpage = Sp(self.driver)
        search_results = searchpage.get_search_results()
        search_results = int(search_results)
        assert search_results > 0
        sleep(3)
    
    def tearDown(self):
        self.driver.close()
        self.driver.quit()
        sleep(3)