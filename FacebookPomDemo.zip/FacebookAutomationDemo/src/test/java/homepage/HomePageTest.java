package homepage;

import org.testng.annotations.Test;

import pages.IdentityPage;
import pages.LoginPage;
import utility.Base;

import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;

public class HomePageTest {

	WebDriver driver;
	Base base = new Base(driver);
	LoginPage facebookLoginPage;
	IdentityPage facebookForgotPasswordPage;

	@BeforeMethod
	public void setUp() {
		driver = base.driverSetup();
		facebookLoginPage = new LoginPage(driver);
		facebookForgotPasswordPage = new IdentityPage(driver);
	}

	@Test
	public void test_LoginFunctionality() throws InterruptedException {
        assertEquals("https://es-la.facebook.com/", driver.getCurrentUrl());
        assertEquals("Facebook - Inicia sesión o regístrate", driver.getTitle());
		facebookLoginPage.fillSignUp();
		Thread.sleep(3000);
		facebookLoginPage.forgotPassword();
        facebookForgotPasswordPage.fillForgotPasswordForm("04121cesar@gmail.com");
        Thread.sleep(3000);
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
