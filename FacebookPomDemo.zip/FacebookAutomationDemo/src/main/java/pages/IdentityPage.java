package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utility.Base;

public class IdentityPage extends Base {

	By findyourAccountHeader = By.xpath("//*[@id=\"identify_yourself_flow\"]/div/div[1]/div/div[2]/h2");
	By emailInput = By.id("identify_email");
	By searchButton = By.id("did_submit");
	By messageError = By.xpath("//*[@id=\"identify_yourself_flow\"]/div/div[2]/div[1]/div[1]");

	public IdentityPage(WebDriver driver) {
		super(driver);
	}
	
	public void fillForgotPasswordForm(String email) throws InterruptedException {
		assertEquals("Recupera tu cuenta", getText(findyourAccountHeader));
		sendKeys(email, emailInput);
		Thread.sleep(1000);
		click(searchButton);
		Thread.sleep(3000);
		assertEquals("No hay resultados de búsqueda", getText(messageError));
	}

}
