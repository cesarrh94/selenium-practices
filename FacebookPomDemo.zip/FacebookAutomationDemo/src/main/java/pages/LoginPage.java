package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.Base;

public class LoginPage extends Base {

	static By createAccountButton = By.linkText("Crear cuenta nueva");
	static By forgotPasswordLink = By.linkText("¿Olvidaste tu contraseña?");

	// register form elements
	By firstNameInput = By.name("firstname");
	By lastNameInput = By.name("lastname");
	By email = By.name("reg_email__");
	By confirmEmail = By.name("reg_email_confirmation__");
	By password = By.name("reg_passwd__");
	By selectDay = By.id("day");
	By selectMonth = By.id("month");
	By selectyear = By.id("year");
	By selectFemaleGender = By.xpath("//*[contains(text(), 'Mujer')]");
	By closeButton = By.xpath("//img[@src='https://static.xx.fbcdn.net/rsrc.php/v3/yO/r/zgulV2zGm8t.png']");

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public void fillSignUp() throws InterruptedException {
		click(createAccountButton);
		Thread.sleep(3000);
		sendKeys("cesar", firstNameInput);
		sendKeys("rodriguez", lastNameInput);
		sendKeys("testemail@test.com", email);
		Thread.sleep(1000);
		sendKeys("testemail@test.com", confirmEmail);
		sendKeys("test1234", password);
		selectByValue("4", selectDay);
		Thread.sleep(1000);
		selectByValue("12", selectMonth);
		Thread.sleep(1000);
		selectByValue("1994", selectyear);
		Thread.sleep(1000);
		click(selectFemaleGender);
		Thread.sleep(1000);
		click(closeButton);
		Thread.sleep(1000);
	}

	public void forgotPassword() {
		click(forgotPasswordLink);
	}

}
