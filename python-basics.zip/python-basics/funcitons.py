# functions, which are named block of code that are designed to do one specific.
# when you want to perform a particular task that you have defined in a function, you
# call the function responsible for it!

# example of a simple function
def greeting():
    print("Hello")

greeting()

# function with parameters
def greet_user(username):
    print(f"Hello, {username.title()}!")

greet_user('cesar')

# function with multiple parameters
# positional parameters/arguments
# FIXME: when you are passing parameters to a function the position and order matters
# just remember it to avoid errors in your code!
def describe_pet(animal_type, pet_name):
    print(f"\nI have a {animal_type}")
    print(f"My {animal_type}'s name is {pet_name.title()}")

# example of positional parameters
describe_pet('dog', 'benji')
describe_pet(animal_type='cat', pet_name='don gato')

# function with return value
def get_formatted_name(first_name, last_name):
    full_name = f"{first_name.title()} {last_name.title()}"
    return full_name

musician = get_formatted_name('jimmy', 'hendrix')
print(musician)

# example of how to make a parameter optional
def get_full_name(first_name, last_name, middle_name = ''):
    # full_name = ''
    if middle_name:
        full_name = f"{first_name} {middle_name} {last_name}"
    else:
        full_name = f"{first_name} {last_name}"
    
    return full_name.title()

print(f"full name: {get_full_name('cesar', 'rodriguez')}")
print(f"full name: {get_full_name('jennifer', 'rodriguez', 'monserrat')}")

# example of a function working with dictionaries
def build_person(first_name, last_name):
    person = {'first_name': first_name, 'last_name': last_name}
    return person

musician = build_person('jimmy', 'page')
print(musician)

# example of a function working with lists
def print_models(unprinted_designs, completed_models):
    while unprinted_designs:
        current_design = unprinted_designs.pop()
        print(f"printing model: {current_design}")
        completed_models.append(current_design)

def show_completed_models(completed_models):
    print("\nthe following models have been printed:")
    for completed_model in completed_models:
        print(completed_model)

unprinted_designs = ['phone case', 'robot pendant', 'dodecahedron']
completed_models = []

print_models(unprinted_designs, completed_models)
show_completed_models(completed_models)
