# a list is a collection of items in a particular order, you can make a list that
# includes the letters or digits numbers.
cars = ['mazda', 'toyota', 'nissan', 'subaru']
print(cars)

# accessing elements in a list by index
print(cars[0])
print(cars[-1])

# accessing to the last element by using len() function
last_list_element = len(cars) - 1
print("here accessing to the last element of the list: " + cars[last_list_element])

# f-string to compose a message properly
car_message = f"the car brand that I like most is {cars[-1]}"
print(car_message)


# --- list homework ---
family_members = ['rafael', 'rosalba', 'cesar', 'jennifer', 'marcos']
print(family_members[0])
print(family_members[1])
print(family_members[2])
print(family_members[3])
print(family_members[4])

message = f"hello {family_members[2]}, welcome home!"
print(message.title())


# modifying a list value's - CRUD operations
motorcycles = ['honda', 'yamaha', 'suzuki']
motorcycles[0] = 'ducati'
print(motorcycles)

# adding elements to the end of a list
motorcycles.append('honda')
print(motorcycles)

# inserting elements into a list in any position
motorcycles.insert(2, 'harley')
print(motorcycles)

# removing elements from a list 
del motorcycles[2]
print(motorcycles)

# removing using pop method 
# if you dont indicates which elements "position" you want to remove it will remove the
# last item in the list.
popped_motorcycle = motorcycles.pop()
print(motorcycles)
print(popped_motorcycle)

popped_motorcycle = motorcycles.pop(0)
print(motorcycles)
print(popped_motorcycle)

# removing an item by value
motorcycles.remove('yamaha')
print(motorcycles)


# organizing a list
# the sort method changes the list permanently
# cars.sort(reverse=True)
print(cars)

# sorting a list temporary with sorted function
print(f'temporaty sorting with sorted() funciton: {sorted(cars)}')
print(cars)

# reverse order in a list
cars.reverse()
print(cars)

# finding list length
print(len(cars))