# a dictionary is python a collection of key-value pairs, where each key is connected to a value, 
# and you can use the key to access the value.
person1 = {
    'name': 'cesar',
    'age': 27
}

print(person1)

# accessing to the dictionary values
person_name = person1['name']
person_age = person1['age']

print(person_name)
print(person_age)

# adding a new key-value pair to the dictionary
person1['profession'] = 'sdet'
print(person1)

# initialize an empty dictionary
person2 = {}
person2['name'] = 'marcos'
person2['age'] = 21
person2['profession'] = 'accountability student'

print(person2)

# modifying values in a dictionary
person2['name'] = 'rafa'
print(person2)

# removing key-value pairs
del person2['profession']
print(person2)

# using the get method to access a value
profession = person1.get('profession', 'No profession value assigned!')
print(f"profession: {profession}")


# looping through all key-value pairs
user = {
    'username': 'ciruspunk',
    'name': 'cesar',
    'age': 27,
    'email': '94cesarrh@gmail.com'
}

for key, value in user.items():
    print(f"key: {key}")
    print(f"value: {value}")
    print("\n")

# looping through all the keys in a dictionary
for key in user.keys():
    print(key)

print("\n")

# looping through all the values in a dictionary
for value in user.values():
    print(value)
