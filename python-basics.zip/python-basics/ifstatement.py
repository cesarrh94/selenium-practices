# checking for equality
cars = ['audi', 'bmw', 'subaru', 'toyota']

for car in cars:
    if car.lower() == 'bmw':
        print(car.upper())
    else:
        print(car.title())


# checking for inequality
pizza_topping = 'pepperoni'

if pizza_topping != 'anchovies':
    print("Hold on the Anchovies")
else:
    print("Yay Anchovies!")


# checking multiple condition with AND & OR operators
day = 8
month = 9

if day == 8 and month == 9:
    print("Today is Test Day, yay!")

team1 = 'psg'
team2 = 'manchester united'

if team1 == 'barcelona' or team2 == 'real madrid':
    print("you know about soccer!")
else:
    print("you know about soccer but you are a pussy XD")


# checking whether a value is in a list, with the IN operator
requested_topping = ['mushrooms', 'onions', 'pineapple']
print(f"Is pineapple on the requested topping list? {'pineapple' in requested_topping}")
print(f"Is pepperoni on the requested topping list? {'pepperoni' in requested_topping}")

# checking whether a value is NOT in a list, with IN NOT operator
banned_users = ['cesar', 'jennifer', 'marcos']
user = 'cesar'

if user.lower() not in banned_users:
    print(f"{user.title()}, you can pass to club!")
else:
    print(f"{user.title()}, you are banned from this club, you cannot pass!")


# if elif else chain

age = 14

if age < 4:
    print("Your admission cost is $0")
elif age < 18:
    print("Your admission cost is $25")
else:
    print("Your admission cost is $40")

age = 19

if age >= 18:
    print("Your admission cost is $40")
elif age > 4:
    print("Your admission cost is $25")
else:
    print("Your admission cost is $0")



# --- if statement homework ---

alien_color = 'blue'

if alien_color.lower() == 'green':
    print("you got 5 points")
elif alien_color.lower() == 'yellow':
    print("you got 10 points")
elif alien_color.lower() == 'red':
    print("you got 15 points")
else:
    print("no color alien exists, please try again!")


age = 65

if age < 2:
    print("baby")
elif age >= 2 and age < 4:
    print("toddler")
elif age >= 4 and age < 13:
    print("kid")
elif age >= 13 and age < 20:
    print("teenager")
elif age >= 20 and age < 65:
    print("adult")
else:
    print("elder")


favorite_fruits = ['apples', 'bananas', 'pineapples', 'strawberries']

fruit = 'apples'

if fruit.lower() in favorite_fruits:
    print(f"I really love {fruit.title()}!")
else:
    print(f"Sorry, {fruit.title()} is not my favorite fruit!")



requested_ingredients = ['mushrooms', 'pepperoni', 'italian sausage', 'green pepper']

for requested_ingredient in requested_ingredients:
    if requested_ingredient == 'green pepper':
        print(f"Sorry, We are out of {requested_ingredient} right now!")
    else:
        print(f"Adding {requested_ingredient}")

print("\nFinished making pizza!")
print("\n")


# --- homework part 2 ---

usernames = ['cirus', 'punk', 'admin', 'muzan', 'bocho']

for username in usernames:
    if username == 'admin':
        print(f"Hello {username.upper()}, would you like to see a status report!")
    else:
        print(f"Hello {username.title()}, thank you for logging in again!")

usernames = ['cesar']

if usernames:
    print("list not empty")
else:
    print("empty list")


current_usernames = ['ciruspunk', 'quekis', 'topu']
new_usernames = ['jenni', 'rafita', 'ciruspunk']

for new_username in new_usernames:
    if new_username in current_usernames:
        print(f"{new_username} is already taken, please enter a new username.")
    else:
        print(f"adding {new_username} to the current_usernames list!")


numbers = [value for value in range(1,11)]

print(numbers)

for number in numbers:
    if number == 1:
        print("1st place")
    elif number == 2:
        print("2nd place")
    elif number == 3:
        print("3rd place")
    elif number == 4:
        print("4th place")
    elif number == 5:
        print("5th place")
    elif number == 6:
        print("6th place")
    elif number == 7:
        print("7th place")
    elif number == 8:
        print("8th place")
    elif number == 9:
        print("9th place")
    else:
        print(f"number {number} is out of range!")