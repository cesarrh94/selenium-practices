mugiwaras = ['luffy', 'zoro', 'nami', 'ussop', 'sanji', 'chopper', 'robin', 'franky', 'brook', 'jimbe']

# loop through an entire list
for mugiwara in mugiwaras:
  print(f"He or She {mugiwara.upper()} is a member of the mugiwaras tripulation!")

print("\nI will be the pirate king! shi shi shi")


# --- homework of working with lists ---
pizzas = ['hawaina', 'pepperoni', 'vegetarian', 'chicken-baccon ranch']
for pizza in pizzas:
  print(f"I like {pizza} pizza!")

print("I really like pizza!")


animals = ['dog', 'cat', 'hamster', 'parrot']
for animal in animals:
  print(f"A {animal} would make a great pet.")


# making numerical list
for value in range(1, 11):
  print(value)

# using range function to make a list of numbers
numbers = list(range(1,6))
print(numbers)
print(min(numbers))
print(max(numbers))
print(sum(numbers))

even_numbers = list(range(1,11, 2))
print(even_numbers)
