# importing unittest module
import unittest
from name_function import get_formatted_name

# this class inherits from unittest
class NamesTestCase(unittest.TestCase):
    """Test for name_function.py"""
    
    # unit test for the get_formatted_name() function.
    # TODO: any method that starts with test_ will be run automatically when we
    # run the this python module
    def test_first_last_name(self):
        """Do names like Zoro Roronoa, works?"""
        formatted_name = get_formatted_name('zoro', 'roronoa')
        # comparing the expected output.
        self.assertEqual(formatted_name, 'Zoro Roronoa')


# TODO: the if block looks at a special variable __name__, which is set when the
# program is executed. If this file is being rus as the main program, the value of
# __name__ is set to __main__
if __name__ == '__main__':
    unittest.main()