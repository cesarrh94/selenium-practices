# writing to an empty file

filename = 'programming.txt'

# to write in a file, we need to pass a second argument to the open() function; that's
# the mode: 'r' for read, 'w' for write, 'a' append and we have a mode for 
# read/write 'r+'
with open(filename, 'w') as file_object:
    file_object.write("I love programming.\n")
    file_object.write("Python, It's the best programming language for beginners!")
