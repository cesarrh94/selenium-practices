# while loops

# the for loops take a collection of items and executes a block of code once for
# for each item in the collection. In contrast, the while oop run as long as or while,
# a certain condition is true.

current_number = 1
while current_number <= 5:
    print(current_number)
    current_number += 1


# using a Flag to indicate when to quit
prompt = "\nTell me something , and I will repeat it back to you:"
prompt += "\nEnter 'quit to end the program. "

active = True
while active:
    message = input(prompt)
    if message == 'quit':
        active = False
    else:
        print(message)

print("\nyou are out the loop successfully!")


# using break to exit a loop
message = "\nPlease enter the name of a city you have visited:"
message += "\n(Enter 'quit' when your are finished) "

while True:
    city = input(message)
    
    if city == 'quit':
        break
    else:
        print(f"I would love to go to {city.title()}!")


# using continue in a loop
# rather than breaking out of the loop without executing the rest of the its code,
# you can use the continue statement to return to the beginning of the loop based on
# the result of conditional test.

current_number = 0
while current_number < 10:
    current_number += 1
    if current_number % 2 == 0:
        continue
    print(current_number)

print("\n")

# FIXME: to avoid infinite loops, remember to always during the code execution the flag
# or condition in it, turns to false or reach the objective!


# --- practical examples of while loops ---

# number 1:  moving items from one list to another
unconfirmed_users = ['alice', 'brian', 'candace']
confirmed_users = []

while unconfirmed_users:
    current_user = unconfirmed_users.pop()
    
    print(f"verifying user: {current_user}")
    confirmed_users.append(current_user)

print("\nthe following users have been confirmed: ")
for confirmed_user in confirmed_users:
    print(confirmed_user)

print("\n")

# number 2: removing all instances of specific values from a list
pets = ['dog', 'cat', 'dog', 'goldfish', 'cat', 'rabbit', 'cat']
print(pets)

while 'cat' in pets:
    pets.remove('cat')

print(pets)


# number 3: filling a dictionary with user input
responses = {}

polling_active = True

while polling_active:
    name = input("\nWhat is your name? ")
    response = input("What is your favorite soccer player? ")
    
    responses[name] = response
    
    repeat = input("Would you like to let another person respond? (yes/no) ")
    repeat = repeat.lower()
    if repeat == 'no' or repeat == 'n':
        polling_active = False

print("\n--- poll results ---")
for name, response in responses.items():
    print(f"{name.title()} favorite soccer player is {response.upper()}")


