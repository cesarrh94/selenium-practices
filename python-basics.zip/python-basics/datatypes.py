# variables
message = "Hello Python World!"
print(message)

message = "Hello Python Crash Course world!"
print(message)

# strings
my_string = "this is my string"
print(my_string)
my_string = "This is my string"
print(my_string.title())
print(my_string.upper())
print(my_string.lower())

# adding newlines and tabs to the string
print("languages:\n\tpython\n\tc\n\tjavascript")



# integers
my_favorite_number = 11
print(my_favorite_number)

# floats
# constant of PI
PI_VALUE = 3.1416
print(PI_VALUE)