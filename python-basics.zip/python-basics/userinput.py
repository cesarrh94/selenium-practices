# the input() function pauses your program and waits for the user to enter some text.
# once Python receives the user's input, it assigns that input to a variable to make it
# convenient for you to work with.

# the input() function tale one argument the prompt.

name = input("What is your name? ")
print(f"Hello {name.title()}, welcome!")

# the input() function interprets everything the user enters as a string.
# the int() function cas the string value to int value
# type() function retrieves the data type the age variable is
age = input("How old are you? ")
age = int(age)
print(f"Age: {age}")
print(type(age))

pi_value = input("Hi, Can you give the round value of PI? ")
pi_value = float(pi_value)

print(type(pi_value))
print(f"round value of PI: {pi_value}")