# JSON - Javascript Object Notation

# the Json module allows you to dump simple Python data structures into a file and load
# the data from that file the next time the program runs.

import json

numbers = [4, 7, 10, 11, 14]
print(numbers)

# json.dump() function takes 2 arguments: a piece of data to store and a file object
# it can use to store the data.
filename = 'numbers.json'
with open(filename, 'w') as file_object:
    json.dump(numbers, file_object)