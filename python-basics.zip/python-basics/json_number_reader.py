import json

filename = 'numbers.json'

# json.load() function to load the information stored in the json file and assign it to
# to the variable.
with open(filename) as file_object:
    numbers = json.load(file_object)

print(numbers)