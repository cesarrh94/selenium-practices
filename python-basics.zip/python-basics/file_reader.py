# reading from a file

# The open() function needs one argument - the name of the file you want to open.
# Python looks for this file in the directory where the program that's currently 
# being executed is stored. The open() function returns an object representing the
# file.

# the With keyword closes the file once access to it is no longer needed.

# reading the entire file
with open('pi_digits.txt') as file_object:
    contents = file_object.read()
print(contents)

# read line by line
filename = 'pi_digits.txt'
print("\nreading line by line of the file:\n")
with open(filename) as file_object:
    for line in file_object:
        print(line)

# making a list of lines from a file
with open(filename) as file_object:
    lines = file_object.readlines()

for line in lines:
    print(line.rstrip())