# a list comprehension combines the for loop allows you to generate this same list
# in just one line of code.

# example no using a comprehension list
squares = []
for value in range(1, 11):
  squares.append(value**2)

print(squares)


# example using comprehension list
sq = [value**2 for value in range(1, 11)]
print(sq)