# tuples let you create a collection of items that cannot change, meaning that is
# immutable, so a tuple is a immutable list.

dimensions = (200, 50)
print(dimensions[0])
print(dimensions[1])

# TypeError because a tuple can not assign a new value to a tuple
# dimensions[0] = 205;

for dimension in dimensions:
  print(dimension)