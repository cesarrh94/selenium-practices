# python modules

# storing your functions in a separate file allows you to hide the
# details of your's programs code and focus on its higher-level logic.

# you can import an entire module & specific functions
# you can provide an alias to the functions and a module


def make_pizza(size, *toppings):
    print(f"\nMaking a {size}-inch pizza with the following toppings:")
    for topping in toppings:
        print(f"- {topping}")
