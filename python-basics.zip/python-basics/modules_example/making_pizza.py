# importing an entire module
# import pizza

# import all functions in a module
# from pizza import *

# importing the specific function and setting up an alias!
from pizza import make_pizza as mp

mp.make_pizza(16, 'pepperoni', 'extra')