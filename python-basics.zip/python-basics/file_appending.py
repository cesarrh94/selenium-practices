filename = 'message.txt'

# we use 'a' append we a file already exists and also has some content in it!
with open(filename, 'a') as file_object:
    file_object.write("this is another random message from a python script.\n")
    file_object.write("i love anime, i love one piece!\n")