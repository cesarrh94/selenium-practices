class User:
    
    def __init__(self, first_name, last_name, age):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
    
    def describe_user(self):
        print(f"user - first name: {self.first_name}")
        print(f"user - last name: {self.last_name}")
        print(f"user - age: {self.age}")
    
    def greet_user(self):
        print(f"\nhello {self.first_name} {self.last_name}, welcome back!\n")

class Privileges:
    
    def __init__(self):
        self.privileges = ['add post', 'delete post', 'ban user']
    
    def show_privileges(self):
        print(f"here are the privileges that the admin has:")
        for privilege in self.privileges:
            print(f" - {privilege}")

class Admin(User):
    
    def __init__(self, first_name, last_name, age):
        super().__init__(first_name, last_name, age)
        self.privileges = Privileges()
    
    

user1 = User('cesar', 'rodriguez', 27)
user2 = User('jennifer', 'rodriguez', 23)
user3 = User('marcos', 'rodriguez', 21)

user1.describe_user()
user1.greet_user()

user2.describe_user()
user2.greet_user()

user3.describe_user()
user3.greet_user()



admin1 = Admin('cirus', 'punk', 27)
admin1.privileges.show_privileges()