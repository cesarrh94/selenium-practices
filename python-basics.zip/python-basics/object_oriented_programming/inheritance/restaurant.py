class Restaurant:
    
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
    
    def describe_restaurant(self):
        print(f"{self.restaurant_name} specialite is {self.cuisine_type}")
    
    def open_restaurant(self):
        print(f"{self.restaurant_name} is open, please enter!")


my_restaurant = Restaurant('baratie', 'french food')
my_restaurant.describe_restaurant()
my_restaurant.open_restaurant()


class IceCreamStand(Restaurant):
    
    def __init__(self, restaurant_name, cuisine_type):
        super().__init__(restaurant_name, cuisine_type)
        self.flavor = ['vanilla', 'chocolate', 'strawberry']

    def get_ice_cream_flavors(self):
        print(f"here the list of flavor of {self.restaurant_name}")
        for flavor in self.flavor:
            print(f" - {flavor}")

my_ice_cream_store = IceCreamStand('dairy queen', 'desserts')
my_ice_cream_store.get_ice_cream_flavors()