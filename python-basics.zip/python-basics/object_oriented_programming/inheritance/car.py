# Inheritance Example:

# parent (superclass)
class Car:

    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
        self.odometer_reading = 0

    def get_descriptive_name(self):
        long_name = f"{self.year} {self.make} {self.model}"
        return long_name

    def read_odometer(self):
        print(f"this car has {self.odometer_reading} miles on it!")

    def update_odometer(self, mileage):
        self.odometer_reading = mileage

    def increment_odometer(self, miles):
        self.odometer_reading += miles

    def fill_gas_tank(self):
         print(f"this car need gas!")


# child (subclass) - class which inherits from Car
class ElectricCar(Car):
    """Represent aspects of a car, specific to electric vehicles."""

    def __init__(self, make, model, year):
        """Initialize attributes of the parent class."""
        super().__init__(make, model, year)
        # defining attribute for the child class
        self.battery_size = 75
    
    # defining method for a the child class
    def describe_battery(self):
        print(f"this car has a {self.battery_size}-kWh battery.")
    
    # method overriding
    def fill_gas_tank(self):
        print(f"the Electric cars doesn't need gas!")


car_1 = Car('toyota', 'ae86', 1986)
print(car_1.get_descriptive_name())
car_1.update_odometer(10000)
car_1.read_odometer()
car_1.increment_odometer(4500)
car_1.read_odometer()
car_1.fill_gas_tank()


electric_car_1 = ElectricCar('tesla', 's', 2019)
print(electric_car_1.get_descriptive_name())
electric_car_1.update_odometer(2000)
electric_car_1.read_odometer()
electric_car_1.increment_odometer(500)
electric_car_1.read_odometer()
electric_car_1.describe_battery()
electric_car_1.fill_gas_tank()

