# importing multiple classes from a module
from car import Car
from car import ElectricCar

# importing an entire module
# import car

# importing all classes from a module
# from car import *

# my_new_car = car.Car('subaru', 'wrx', 2004)
my_new_car = Car('subaru', 'wrx', 2004)
print(my_new_car.get_descriptive_name())

# my_electric_car = car.ElectricCar('tesla', 'x', 2022)
my_electric_car = ElectricCar('tesla', 'x', 2022)
print(my_electric_car.get_descriptive_name())