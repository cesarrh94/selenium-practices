class Dog:
    
    def __init__(self, name, age):
        """Initialize name and age attributes"""
        self.name = name
        self.age = age
        
    def sit(self):
        """Simulate a dog sitting in respond to command"""
        print(f"{self.name} is now sitting.")
    
    def roll_over(self):
        """Simulate rolling over in response to a command"""
        print(f"{self.name} rolled over!")

# making an instance from a class
my_dog = Dog('Benji', 4)

# accessing attributes using DOT notation
print(f"my dog's name is {my_dog.name}")
print(f"my dog's age is {my_dog.age}")

# calling methods
my_dog.sit()
my_dog.roll_over()

# creating multiple instances of a class
your_dog = Dog('rocky', 11)

print(f"my dog's name is {your_dog.name}")
print(f"my dog's age is {your_dog.age}")

your_dog.sit()
your_dog.roll_over()